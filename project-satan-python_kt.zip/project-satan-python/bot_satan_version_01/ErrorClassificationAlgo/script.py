import numpy as np
import pandas as pd
import tensorflow as tf
from os.path import abspath, join, dirname, isfile
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from tensorflow import keras


BASE_FILE_PATH = dirname(abspath(__file__))
data_file_path = join(BASE_FILE_PATH, 'data2_error.csv')
TRAINED_MODEL_PATH = join(BASE_FILE_PATH, 'local_ann_model.h5')
dataset = pd.read_csv(data_file_path)


def train_model():
    cv = CountVectorizer(max_features=468)
    X = cv.fit_transform(dataset['Registered_error']).toarray()
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state = 0)

    ann = tf.keras.models.Sequential()
    ann.add(tf.keras.layers.Dense(units=7, activation='relu'))
    ann.add(tf.keras.layers.Dense(units=7, activation='relu'))
    ann.add(tf.keras.layers.Dense(units=7, activation='softmax'))
    ann.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics = ['accuracy'])

    ann.fit(X_train, y_train, batch_size=32, epochs=100)
    y_pred = ann.predict(X_test).argmax(axis=1)

    from sklearn.metrics import confusion_matrix, accuracy_score
    cm = confusion_matrix(y_test, y_pred)
    # print(cm)
    accuracy_score(y_test, y_pred)
    ann.save(TRAINED_MODEL_PATH)


def predict_error(err):
    if not isfile(TRAINED_MODEL_PATH):
        train_model()
    ann = keras.models.load_model(TRAINED_MODEL_PATH)

    b=pd.Series([err])
    dataset2=dataset['Registered_error'].append(b,ignore_index = True)
    xv = CountVectorizer(max_features=468)
    # dataset2
    e = xv.fit_transform(dataset2).toarray()
    pred = ann.predict(e).argmax(axis=1)
    res=pred[-1]
    if(res==1):
        errtype="WARNING"
    elif(res==2):
        errtype="GLOBAL ERROR"
    elif(res==4):
        errtype="CRITICAL ERROR"
    elif(res==3):
        errtype="HTTP ERROR"
    else:
        errtype="IGNORE ERROR"
    return errtype

# ann.save('local_ann_model.h5')
# ann = keras.models.load_model('local_ann_model.h5')
# err="user not found"
# ErrClass=predict_error(err)
# print(ErrClass)



"""
import numpy as np
import pandas as pd
import tensorflow as tf
from os.path import abspath, join, dirname, isfile
from sklearn.feature_extraction.text import CountVectorizer
from tensorflow import keras




def predict_error(err):
    b=pd.Series([err])
    dataset2=dataset['Registered_error'].append(b,ignore_index = True)
    xv = CountVectorizer(max_features=468)
    # dataset2
    e = xv.fit_transform(dataset2).toarray()
    pred = ann.predict(e).argmax(axis=1)
    res=pred[-1]
    if(res==1):
        errtype="WARNING"
    elif(res==2):
        errtype="GLOBAL ERROR"
    elif(res==4):
        errtype="CRITICAL ERROR"
    elif(res==3):
        errtype="HTTP ERROR"
    else:
        errtype="IGNORE ERROR"
    return errtype


# ann.save('local_ann_model.h5')
err="user not found"
ErrClass=predict_error(err)
print(ErrClass)


"""