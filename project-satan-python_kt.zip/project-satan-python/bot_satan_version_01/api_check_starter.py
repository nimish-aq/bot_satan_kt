"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Last Modified : 2021-06-03

> summary : module script take a json file argument, reads all required data, if requirements are complete then
            initiates api error checker process.
"""


import argparse
import json
from os.path import isfile

from first_step_error_checker import process_starter

parser = argparse.ArgumentParser(description='API ERROR CHECKER BOT')

parser.add_argument('config_file')

args = parser.parse_args()

if isfile(args.config_file):
    """
    checks given argument of file is actually file or not.
    reads json data from file
    initiates error checking process as it calls process_starter function. 
    """
    file = open(args.config_file)
    data = json.load(file)
    try:
        # initiating process of error calculation
        process_starter(data['influx_db_config'], data['mysql_db_config'], data['process'],
                        data['apis'], data['log_file_base_path'], data['log_file_name'],
                        data["query_stage_1"], data["query_stage_2"],
                        _lower_time=data.get('lower_time'), _current_time=data.get('current_time'),
                        text_match_log_file=data.get('text_match_log_file'),
                        grafana_dashboards=data.get("grafana_dashboards"),
                        process_kwargs=data.get('process_kwargs')
                        )
    except KeyError as e:
        print(f"key error key {e} not found in config file")
    except Exception as e:
        print(e)
else:
    print(f"{args.config_file} is not a valid file path")

