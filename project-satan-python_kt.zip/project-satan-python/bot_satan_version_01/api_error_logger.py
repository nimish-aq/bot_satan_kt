"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Last Modified : 2021-06-18

> summary : global logger class for complete procedure

"""

from logger.logger import get_logger


class Logger:
    """
        Logger class
        modify messages adds api name if logging is going on for second step error check
        also do print same messages
    """
    def __init__(self, log_file_base_path, log_file_name):
        """
        :param log_file_base_path: log_file_base_path
        :param log_file_name: log_file_name
        """
        self.logger = get_logger(log_file_base_path, log_file_name)
        self.API_LOG = self.CURRENT_API = None

    def write_logs(self, level, message, indent=0, do_print=False):
        """
        :param level: error level ex - debug / error / info
        :param message: error message - text string
        :param indent: indent to apply in messages to beautify messages
        :param do_print: bool : to print message or not
        """
        if self.API_LOG and self.CURRENT_API:
            message = ": API {} : {}".format(self.CURRENT_API, message)
        if do_print:
            print(message)
        log_function = getattr(self.logger, level)
        log_function(message)
