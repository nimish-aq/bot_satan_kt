"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Updates on method api_error_status : 2021-07-16 [Siddhika Nag]
> last modified : 2021-07-28
> Summary : Module contains a class with methods for all required DB operations on api_error_config_db
            api_error_config_db is heart of bot satan DB.
            and this module is controlling channel of api_error_config_db

            Here every method contains specific query or combined queries or multiple queries

"""


import json

import mysql.connector

import uuid as lib_uuid

class APIErrorDBClass:
    """
    Establishes connection with api errors database
    this class contains all required methods and queries to fetch and insert to api errors database.
    """
    unknown_error_id = None

    def __init__(self, logger):
        """
        Initialize connection with api_error_config_db
        where errors data is stored in relational database
        """
        self.logger = logger
        creds = dict(host="10.221.86.35", user="root",
                       database="api_error_config_db", password="Ttpl@123", port="3307")
        try:
            self.db_con = mysql.connector.connect(**creds)
        except Exception:
            self.logger.write_logs('error', f"mysql connection failed exiting process : credentials {creds}")
            exit(0)
        self.cursor = self.db_con.cursor()

    def fetch_threshold_conditions(self, process, api):
        """
        fetches threshold conditions for given api
        :param process: process name
        :param api: api name
        :return: json data of threshold condition
        """
        q = f"""select threshold_conditions from api where api_name = '{api}' 
                and 
        id in (select api from process_api_m2m where process in (select id from process where process = '{process}'))
        """
        try:
            self.cursor.execute(q)
            data = self.cursor.fetchall()

            return json.loads(data[0][0]) if data else dict()
        except Exception as e:
            self.logger.write_logs('error', "{e} : method APIErrorDBClass.fetch_threshold_conditions : query {q}".
                                   format(e=e, q=q.replace('\n', '')),)
        return {}

    def fetch_all_error_categories(self):
        """
        :return: returns all defined error category list
        """
        q = f"select error_category from error_category where error_category not like '%unknown%'"
        try:
            self.cursor.execute(q)
            data = self.cursor.fetchall()
            return [i[0] for i in data]
        except Exception as e:
            self.logger.write_logs('error', " {e} : method APIErrorDBClass.fetch_all_error_categories : query {q}".
                                   format(e=e, q=q.replace('\n', '')),)
            return []

    def fetch_all_defined_errors(self, process, api):
        """
        :param process: process name
        :param api: api name
        :return: all defined errors text data of api under given process
        """
        return self.fetch_errors(process, api, self.fetch_all_error_categories())

    def sql_where_clause_in_condition_maker(self, pattern):
        """
        multiple times used by class methods
        :param pattern: any pattern list or string or tuple
        :return: right pattern for mysql 'in' condition list query pattern
        """
        if isinstance(pattern, tuple):
            pass
        elif isinstance(pattern, list) or isinstance(pattern, set):
            pattern = tuple(pattern)
        elif isinstance(pattern, str):
            pattern = (pattern,)

        if len(pattern) == 1:
            pattern = f"('{pattern[0]}')"
        return pattern

    @property
    def unknown_errors_category_id(self) -> int:
        """
        :return: unknown errors category id
        """
        if self.unknown_error_id:
            return self.unknown_error_id
        query = "select id from error_category where error_category = 'unknown_errors';"
        try:
            self.cursor.execute(query)
            self.unknown_error_id = self.cursor.fetchall()[0][0]
            return self.unknown_error_id
        except Exception as e:
            self.logger.write_logs('error', " {e} : method APIErrorDBClass.unknown_errors_category_id : query {query}".
                                   format(e=e, query=query.replace('\n', '')), )
            return None

    # def fetch_errors_for_apis(self, api_ids, ):

    def fetch_all_errors_under_process(self, process, category_id):
        """
        all registered errors under a process and category
        :param process: process
        :param category_id: category_id
        :return: errors list
        """
        query = f"select distinct error from error where id in (select error from api_error where api in (select id from api where id in (select api from process_api_m2m where process in (select id from process where process = '{process}'))) and category = {category_id})";
        try:
            self.cursor.execute(query)
            return [i[0] for i in self.cursor.fetchall()]
        except Exception as e:
            self.logger.write_logs('error', f"exception in api_error_mysql.fetch_all_errors_under_process : exception {e} : query  {query}")
            return []

    def fetch_global_errors(self, process):
        """
        all global errors under a process
        :param process: process
        :return: errors list
        """
        category = 'global_errors'  # id = 1
        return self.fetch_all_errors_under_process(process, 1)

    def fetch_all_warnings(self, process):
        """
        all global errors under a process
        :param process: process
        :return: errors list
        """
        category = 'warnings'  # id = 5
        return self.fetch_all_errors_under_process(process, 5)


    def fetch_http_errors(self, process):
        """
        all http errors under a process
        :param process: process
        :return: errors list
        """
        category = 'http_errors' # id = 2
        return self.fetch_all_errors_under_process(process, 2)

    def fetch_errors(self, process, api, error_category):
        """
        :param process: process name
        :param api: api name
        :param error_category: error category name
        :return: text list of errors for given api, process which falls in given category
        """
        error_category = self.sql_where_clause_in_condition_maker(error_category)
        query = f"""
        select error from error 
            where id in (select error from api_error where 
                category in (select id from error_category where error_category in {error_category} )
                and 
                api in (select id from api where
                            api_name = '{api}'
                            and
                            id in  (select api from process_api_m2m
                                where process in (select id from process where process = '{process}')
                                    )
                        )
                )
        """
        try:
            self.cursor.execute(query)
            data = self.cursor.fetchall()
            return [i[0] for i in data]
        except Exception as e:
            self.logger.write_logs('error', " {} : method APIErrorDBClass.fetch_errors : query {}".
                                   format(e, query.replace('\n', '')))
            return []

    def insert_unknown_errors(self, process, api, errors: set, error_count_dict:dict, error_count, date_time, epoch_time):
        """
        :param process: process name
        :param api: api name
        :param errors: list of error text
        :return: None
        Inserts given errors as unknown errors for given api
        """
        try:
            q = "select error from error"
            self.cursor.execute(q)
            existing_errors = {i[0] for i in self.cursor.fetchall()}
            # rectifying already existing errors
            non_existing_errors = errors - existing_errors
            non_existing_errors = [i.replace("'", "\\'") for i in non_existing_errors]
            errors = [i.replace("'", "\\'") for i in errors]
            if non_existing_errors:
                self.logger.write_logs('info', 'inserting unknown errors')
                str_data = ''.join([f"('{error}')," for error in non_existing_errors])
                q = f"insert into error (`error`) values {str_data[:-1]} ;"
                self.cursor.execute(q)
                self.db_con.commit()
            else:
                self.logger.write_logs('info', 'all unknown errors already exist')

            # fetching api id from given process and api
            self.cursor.execute(self.api_id_fetcher_query(process, api))
            api_id = self.cursor.fetchall()[0][0]
            # category_id = self.unknown_errors_category_id
            error_tuple = self.sql_where_clause_in_condition_maker(errors)

            # now mapping inserted data into unknown categories in given process and api
            api_id = int(api_id)
            # category_id = int(category_id)
            # fetch existing data first to be safe from duplicate error
            q = f"""select {api_id} as 'api', id as 'error', {self.unknown_errors_category_id} as 'category' from error where error in 
                    {error_tuple}
                """
            self.cursor.execute(q)
            to_insert_data = self.cursor.fetchall()
            q = """
                        select `api`, `error`, `category` from api_error
                """
            self.cursor.execute(q)
            existing_data = self.cursor.fetchall()
            to_insert_data = tuple(set(to_insert_data) - set(existing_data))
            if to_insert_data:
                if len(to_insert_data) == 1:
                    to_insert_data = str(to_insert_data)[1:-2]
                else:
                    to_insert_data = str(to_insert_data)[1:-1]
                q = f"insert into api_error (`api`, `error`, `category`) values {to_insert_data}"
                self.cursor.execute(q)
                self.db_con.commit()
                self.logger.write_logs('info', 'inserted into api_error table for unknown errors')
            else:
                self.logger.write_logs('info', 'all unknown errors relation already exists')

            # time entries of found unknown errors
            error_tuple = self.sql_where_clause_in_condition_maker(errors)

            q = f"""
            insert into error_history_log (`api_error`, `epoch_time`, `date_time`)
            select api_error.id as api_error, '{epoch_time}' as epoch_time, '{date_time}' as date_time from api_error
            where
             api_error.error in
             (select error.id from error where error.error in {error_tuple} )
             and 
             api_error.api = {api_id}
              and
              api_error.category = {self.unknown_errors_category_id};
            """

            for error in errors:
                try:
                    q = f"""
                    insert into error_history_log (`api_error`, `epoch_time`, `date_time`, `error_count`)
                    select api_error.id as api_error, '{epoch_time}' as epoch_time, '{date_time}' as date_time, {error_count_dict.get(error, 1)} as error_count from api_error
                    where
                     api_error.error in
                     (select error.id from error where error.error = '{error}')
                     and 
                     api_error.api = {api_id}
                      and
                      api_error.category = {self.unknown_errors_category_id};
                    """
                    self.cursor.execute(q)
                except Exception as e:
                    self.logger.write_logs('error', f'{e} : error while executing query {q}')
            self.db_con.commit()

            q = f'select sum(error_count) from error_history_log where date_time = "{date_time}" and ' \
                f'api_error in (select id from api_error where api = {api_id})'
            self.cursor.execute(q)
            entries_count = self.cursor.fetchone()[0]
            if float(entries_count) != float(error_count):
                self.logger.write_logs('error', f'error_history_log entries for unknown error mismatch : entries {entries_count} '
                                                f': errors {error_count} : NOTE this error is for prod while testing '
                                                f'this error can occur')
        except Exception as e:
            self.logger.write_logs('error', " {e} : method APIErrorDBClass.insert_unknown_errors "
                                            "here multiple queries executed check with caution : "
                                            "last executed query {q}".format(e=e, q=q.replace('\n', '')), )

    def rectify_unknown_errors(self, process, api):
        """
        process to start after little classification of unknown errors
        process deletion records from error and api_error after identification of unknown errors
        delete from error table and in cascading auto delete from api_errors

        :param process: process name
        :param api: api name
        :return: None
        """
        q1 = f"""select error from error where 
                id in (select error from api_error where 
                    category != {self.unknown_errors_category_id}
                    and
                    api in (select id from api where api = '{api}' and 
                        id in (select api from process_api_m2m where 
                            process in (select id from process where process = '{process}')
                               )
                            )
                        )
            """
        self.cursor.execute(q1)
        known_errors =self.cursor.fetchall()
        base_delete_query = f"""delete from error where ' 
                id in (select error from api_error where 
                    category  = {self.unknown_errors_category_id}
                    and
                    api in (select id from api where api = '{api}' and 
                        id in (select api from process_api_m2m where 
                            process in (select id from process where process = '{process}')
                               )
                            )
                        )
                and 
                (error_like_query)
                """
        error_like_query = ""
        for i in known_errors:
            error_like_query += f"or error like '%{i}%'"
        error_like_query = error_like_query[2:]

        if known_errors:
            # if there is some known errors then only process should work
            # otherwise it will remove all unknown_errors
            base_delete_query = base_delete_query.replace('error_like_query', error_like_query)
            self.cursor.execute(base_delete_query)
            self.db_con.commit()

    def fetch_unknown_errors_raw_data(self, process, api):
        """
        :param process: process name
        :param api: api name
        :return: list of unknown errors to conduct manual process on unknown errors
        """
        q = f"""select from error where ' 
                id in (select error from api_error where 
                    category  = {self.unknown_errors_category_id}
                    and
                    api in (select id from api where api = '{api}' and 
                        id in (select api from process_api_m2m where 
                            process in (select id from process where process = '{process}')
                               )
                            )
                        )
                """
        self.cursor.execute(q)
        return self.cursor.fetchall()

    def api_id_fetcher_query(self, process, api):
        """
        :param process: process name
        :param api: api name
        :return: returns api id fetch query to be used in another query as sub query
        """
        return f"""select id from api where api_name = '{api}' and 
                        id in (select api from process_api_m2m where 
                            process in (select id from process where process = '{process}')
                            )
                """

    def update_unknown_errors(self, process, api, error_string, category):
        """
        method for manual process
        developer will use this to update error_category data
        :param error_string: error string
        :param category: category
        :return:
        """
        q = f"insert into error (`error`) values ('{error_string}')"
        self.cursor.execute(q)
        self.db_con.commit()

        q = f"""insert into api_error (`api`, `error`, `category`) 
                values 
                (
                    ({self.api_id_fetcher_query(process, api)}),
                    (select id from error where error = '{error_string}'),
                    (select id from error_category where error_category = '{category}')
                )
            """
        self.cursor.execute(q)
        self.db_con.commit()

    def fetch_ignorable_errors(self, process, api):
        """
        :return: ignorable errors of give api, process
        """
        try:
            q = f"""select error from error where
                    id in (select error from api_error where
                            api  in ({self.api_id_fetcher_query(process, api)})
                            and 
                            category = (select id from error_category where error_category = 'ignore_errors' )
                            )    
                """
            self.cursor.execute(q)
            data = self.cursor.fetchall()
            return [i[0] for i in data] if data else []
        except Exception as e:
            return []

    def api_error_status(self, process, api,is_alert,last_update_timestamp, logger):
        """
        Function to set process and api last alert details in MySQL

        Parameters
        ------------
        process : NB/SB
        api : API for which alert is triggered
        is_alert : 0/1 [1 : alerting 0 : clear]
        last_update_timestamp : timestamp of event

        Return 
        -------------
        uuid : Unique id to identify each alert
        """
        uuid = None
        try :
            query = """
                  select uuid,active from api_error_status where process = '%s' and api = '%s'
            """%(process, api)
            self.cursor.execute(query)
            data = self.cursor.fetchall()
            uuid, active = data[0] if data else (None, None)
            # print(uuid , active)
            if uuid is None or (is_alert != 0 and is_alert != int(active)):
                uuid= str(lib_uuid.uuid4())
                # print("New uuid generated",uuid)
            query = """
                  INSERT INTO api_error_status (`process`,api,active,last_update_timestamp,uuid)
                  VALUES ('%s','%s',%s, %s,'%s' )
                  ON DUPLICATE KEY UPDATE
                     active = VALUES(active), 
                     last_update_timestamp = VALUES(last_update_timestamp),
                     uuid =  VALUES(uuid)
            """%(process, api,is_alert,last_update_timestamp,uuid)
            self.cursor.execute(query)
            self.db_con.commit()
        except Exception as e:
            logger.write_logs('error', f"error occurred while processing method 'api_error_status' : {e}: last executed query {query}")
        return uuid             
# api_error_instance = APIErrorDBClass()
