"""
Notification Sending mechanism for bss

Standalone, Independent from BotSatan

We pull data from a given server
    as we pull data, we note down the max retrieve data id, for next time processing and we pull next time data after that id

    so for this  we have measurement  - 'bss_max_id_tracker_measurement'

We pull data for columns - ['NODE_ID','SERVER_NAME', 'SUBJECT', 'STATUS', 'DATE']

Status is alert bit,
    if status 1 then alert condition if status 0 then alert is down


We retrieve data, reverse sort it, and look for alert conditions and respective data,
    we process over count sum of status bits.


    However in end if status bit is 0 then no alert
    if status bit is not 0, then we need to send sum of status bit, what we have seen so far till that time


if alert bit is up, it will send alert notification.
if this is down, it will check if previous alert bit was up then it will send alert down notification


"""


import pandas as pd
import pymsteams
from datetime import datetime, timedelta
from influx import InfluxDB
import mysql.connector
# import MySQLdb


# setup things start from here

webhook_url = 'https://globetouch1.webhook.office.com/webhookb2/264a56f2-0529-4995-9c3d-d2cc84abcfe5@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/85358df8625640ce91118b56133a735f/83df8e4c-fc16-4b73-b9cc-a460ea7d55f5'

process = 'BSS Notification'

db = 'matrics'

measurement = 'bss_notification'
bss_max_id_tracker_measurement = 'bss_max_id_tracker_measurement'

host_main = 'http://10.221.86.30:8086'

counter_connection = InfluxDB(host_main)

mysql_creds = dict(host="192.168.102.144", user="bssuser1",
             database="myindian", password="Bssuser@123", port=3306)

# setup things end here

data_connection = mysql.connector.connect(**mysql_creds)
# data_connection = MySQLdb.connect(**mysql_creds)

data_cursor = data_connection.cursor()


def get_query():
    _date = datetime.utcnow() - timedelta(minutes=15)
    data_fetch_query = f'select ID, NODE_ID, SERVER_NAME, SUBJECT, STATUS, DATE from tfault_alterts where DATE > "{_date}" '  # order by date desc

    alert_data = counter_connection.select_where(db, bss_max_id_tracker_measurement, fields='max_id',
                                            where='time > 0', desc=True, limit=1)
    alert_data = alert_data['results'][0]['series'] if alert_data['results'][0].get('series') else None
    if alert_data:
        previous_id = alert_data[0]['values'][0][1]
    else:
        previous_id = None
    filter = ''
    if previous_id or previous_id == 0:
        print(' previous id', previous_id)
        filter = f'and ID > "{previous_id}"'
    data_fetch_query += filter
    print(data_fetch_query)
    return data_fetch_query


data_fetch_query = get_query()


df = pd.read_sql(data_fetch_query, data_connection)
if df.empty:
    print("No incoming data. Quiting.")
    exit(0)

max_ID = max(df['ID'])
counter_connection.write(db, bss_max_id_tracker_measurement, fields={'max_id': max_ID},)


# counter_con = counter_connection()
# data_cursor = data_con.cursor()

#
# data = [
#     (1, 'BH_DEV', 'Unable to push notification', 1, '2021-10-26 11:34:49'),
#     (1, 'BH_DEV', 'OCS error sendOCSStatus', 1, '2021-10-26 11:37:34'),
#     (1, 'BH_DEV', 'Unable to push notification', 0, '2021-10-26 11:37:44'),
#     (1, 'BH_DEV', 'Unable to push notification', 1, '2021-10-26 11:38:44'),
#     (1, 'BH_DEV', 'Unable to push notification', 1, '2021-10-26 11:38:49'),
# ]


columns = ['NODE_ID','SERVER_NAME', 'SUBJECT', 'STATUS', 'DATE']
df = df[columns]
# df = pd.DataFrame(data, columns=columns)
new_df = pd.DataFrame(columns=columns)
by_pass_df = pd.DataFrame(columns=columns)

# reversing dataframe, as we need to look from latest
rdf = df.sort_values('DATE', ascending=[False])


for index, i in rdf.iterrows():
    _df = i[['NODE_ID', 'SERVER_NAME', 'SUBJECT']]
    _by_pass = by_pass_df[['NODE_ID', 'SERVER_NAME', 'SUBJECT']]
    if not _by_pass.empty and len(_by_pass.append(_df).drop_duplicates()) == len(_by_pass):
        # if not distinct then move forward
        continue
    # only distinct values will be able to come here
    if i['STATUS'] == 0:
        new_df = new_df.append(i)
        by_pass_df = by_pass_df.append(i)  # not being used

    else:
        new_df = new_df.append(i)

    # finally new_df have all distinct values


def get_updated_count(x):
    """
    status is alert_bit
    here we are updating status
    if alert is 0, then it will insert alert bit 0, and will return same
    if alert bit is any value, then it will add this with previous value, and will insert sum and return same
    """
    (node_id, server_name, subject, status) = x[['NODE_ID', 'SERVER_NAME', 'SUBJECT', 'STATUS']]
    tags = {
        'node_id': node_id,
        'server_name': server_name,
        'subject': subject,
    }
    if node_id == '' or server_name == '' or subject == '':
        print('skipping alert as one of identifier data is blank')
        return 0

    alert_data = counter_connection.select_where(db, measurement, fields='status',
                                            tags=tags,
                                            where='time > 0', desc=True, limit=1
                                            )
    alert_data = alert_data['results'][0]['series'] if alert_data['results'][0].get('series') else None
    if alert_data:
        previous_status = alert_data[0]['values'][0][1]
    else:
        previous_status = 0
    if status:
        status += previous_status
    counter_connection.write(db, measurement, fields={'status': status},
                 tags=tags)
    return status


def send_teams_notifications(alert_data):
    """
    Sending teams notification on basis of NEW_STATUS count

    :param alert_data:
    :return:
    """
    global process, webhook_url
    (node_id, server_name, subject, is_alert) = alert_data[['NODE_ID', 'SERVER_NAME', 'SUBJECT', 'NEW_STATUS']]
    if node_id == '' or server_name == '' or subject == '':
        print('skipping alert as one of identifier data is blank')
        return
    process = process.upper()
    myTeamsMessage = pymsteams.connectorcard(webhook_url)

    if is_alert:
        myTeamsMessage.title(f"[Alerting] {subject} : {server_name} : {node_id}")
        myTeamsMessage.color("#FF0000")
    else:
        myTeamsMessage.title(f"[Clear] {subject} : {server_name} : {node_id}")
        myTeamsMessage.color("#228B22")

    message_dict = {False: f"Closed alert for {subject}",
                    True: "ALERT!!!!Monitoring Bot has figured out more failures for %s in Last 15 min.To see details of error please check below links and error details : " % (
                        subject)}

    myTeamsMessage.text(message_dict[is_alert > 0])
    # if is_alert:
    # for _index, x in alert_data.iterrows():
    myMessageSection = pymsteams.cardsection()
    # (node_id, server_name, subject, status) = x[['NODE_ID', 'SERVER_NAME', 'SUBJECT', 'NEW_STATUS']]
    # print(node_id, status)
    myMessageSection.title(f"Details")
    myMessageSection.addFact("NODE ID", str(node_id))
    myMessageSection.addFact("SERVER NAME", str(server_name))
    myMessageSection.addFact("SUBJECT", str(subject))
    myMessageSection.addFact("ERROR COUNT STATUS", str(is_alert))
    myTeamsMessage.addSection(myMessageSection)

    # else:
    #     myMessageSection = pymsteams.cardsection()
    #     myMessageSection.title("Closed Alert for below apis")
    #     for _count, x in enumerate(apis, start=1):
    #         myMessageSection.addFact(f"{_count}", str(x))
    #     myTeamsMessage.addSection(myMessageSection)

    # myMessageSection = pymsteams.cardsection()
    # myMessageSection.title("Detail Links")
    # myMessageSection.addFact("Error Percent Dashboard", error_percent_dashboard)
    # myMessageSection.addFact("Error Detail Dashboard", error_details_dashboard)

    if is_alert:
        nessage_section_2 = pymsteams.cardsection()
        myMessageSection.title("Note")
        myMessageSection.text(
            "This Alert will be automatically closed as soon lag value falls below defined threshold")
        myTeamsMessage.addSection(nessage_section_2)
    myTeamsMessage.send()

# here we are finding sum of alerts, with grouping of other values
df2 = new_df.groupby(['NODE_ID', 'SERVER_NAME', 'SUBJECT'])['STATUS'].sum().reset_index()

temp_df = new_df[new_df['STATUS'] == 0]
# data of subjects, whose alerts been down, or got down at a previous time

if not temp_df.empty:
    # here get_updated_count function will put down all open alerts, which ever comes in temp dataframe,
    # also will update in database
    temp_df.apply(get_updated_count, axis=1)


if not df2.empty:
    # here we will pick latest updated status,
    # if alert is open will fire alert as open alert
    # if alert is closed will fire alert closed notification

    df2['NEW_STATUS'] = df2.apply(get_updated_count, axis=1)
    df2.apply(send_teams_notifications, axis=1)

print('script success')
