"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Last Modified : 2021-06-18

> summary : db connection class.
            Implemented Error Catching, if error then tries again after recreating instance, as simetimes
            Failing is because of cursor expires.
            Logging Implemented.

"""

import mysql.connector


class DBConnection:
    """
    mysql connection class from where data is being picked to calculate error percent
    """
    def __init__(self, connection_credentials, logger):
        """
        :param connection_credentials: connection credentials of db
        """
        self.con = None
        self.cursor = None
        self.connection_used = 0
        self.logger = logger
        self.connection_credentials = connection_credentials
        self.reconnect()

    def reconnect(self):
        """
        to connect and to reconnect with db if connection breaks
        """
        try:
            self.logger.write_logs('info', 'connecting with database')
            self.connection_used = 0
            self.con = mysql.connector.connect(**self.connection_credentials)
        except Exception as e:
            self.logger.write_logs('error', f"error in connection with mysql on {self.connection_credentials}")
            exit(0)
        self.cursor = self.con.cursor()

    def query_executor(self, query):
        """
        query executor method in db
        :param query: sql query
        """
        try:
            self.cursor.execute(query)
            self.connection_used += 1
            return self.cursor
        except mysql.connector.errors.OperationalError as e:
            self.logger.write_logs('warning', f'MYSQL_CONNECTION_ERROR: OperationalError : {e}')
            self.cursor = self.con.cursor()
            # logger.write_logs('info', 'courser recreated')
            return self.query_executor(query)
        except Exception as e:
            self.logger.write_logs('warning', f'MYSQL_CONNECTION_ERROR : {e}')
            if not self.connection_used:
                self.logger.write_logs('error', f"{e} : At DBConnection.query_executor ")
            self.reconnect()
            return self.query_executor(query)
