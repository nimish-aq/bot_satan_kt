"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Last Modified : 2021-07-21

> summary : API Error checker second step second step error percent compare
            with threshold and push analysis result to influx
"""

import re
# some_file.py
import sys
from os.path import abspath, dirname, join
# insert at 1, 0 is the script path (or '' in REPL)
algo_path = join(dirname(dirname(abspath(__file__))), 'ErrorClassificationAlgo')
print("algo_path ", algo_path)
sys.path.insert(1, algo_path)
from datetime import datetime
from fuzzywuzzy import fuzz
from fuzzy_match import algorithims
from difflib import SequenceMatcher


from api_error_mysql.api_error_mysql import APIErrorDBClass
from ErrorClassificationAlgo.script import predict_error


class ErrorsCatcher:
    """
    Error catcher class for second step
    """

    def __init__(self, query: str, text_match_file, logger, db_con, influx_client, influx_db,
                 unknown_error_measurement, grafana_dashboards, tensorflow_prediction_log):
        """
          :param query: query to be executed for fetching data of errors
          :param text_match_file: file instance to store matching percent of errors
          """
        self.query = query
        self.text_match_file = text_match_file
        self.logger = logger
        self.db_con = db_con
        self.influx_client = influx_client
        self.influx_db = influx_db
        self.unknown_error_measurement = unknown_error_measurement
        self.api_error_instance = APIErrorDBClass(logger)
        self.grafana_dashboards = grafana_dashboards
        self.tensorflow_prediction_log = tensorflow_prediction_log

    def match_string(self, registered_error, error, raw_error):
        """
        match checker of error and registered error
        also stored matching percent between both from multiple algo
        :param registered_error: registered_error
        :param error: error
        :param raw_error: raw_error
        :return: True / False : matched or not
        """
#         pattern = "registered_error|error|raw_error|exist_in_error|exist_in_raw_error|ratio|" \
#                   "partial_ratio|cosine|levenshtein|" \
#                   "jaro_winkler|trigram|" \
#                   "sequence_matcher"


        # column names above


#         registered_error = registered_error.lower()
#         if self.text_match_file:


#             data = f"""
# {registered_error}|{error}|
# {1 if registered_error in error else 0}|{1 if registered_error in raw_error else 0}|
# {round(fuzz.ratio(registered_error, error), 2)}|
# {round(fuzz.partial_ratio(registered_error, error), 2)}|
# {round(100 * algorithims.cosine(registered_error, error), 2)}|{round(100 * algorithims.levenshtein(registered_error, error), 2)}|
# {round(100 * algorithims.jaro_winkler(registered_error, error), 2)}|{round(100 * algorithims.trigram(registered_error, error), 2)}|
# {round(100 * SequenceMatcher(a=registered_error, b=raw_error).ratio(), 2)}
#                 """


#             data = '\n' + data.replace('\n', '')


#             self.text_match_file.write(data)
# on above data is being appended


# no use case for above all code, it was just a testing part to check which algo gives best output to find match
        # with errors and categorizing them
# here above all write a csv file

        return registered_error in error or registered_error in raw_error # in raw_error or match > 90

    def tensorflow_predict(self, raw_error):
        if self.tensorflow_prediction_log:
            error_type = predict_error(raw_error)
            _date = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
            prediction_data = f'{_date}|{raw_error}|{error_type}'
            self.tensorflow_prediction_log.write(prediction_data)

    def check_downstream_system_error(self, process, api, lower_time, current_time, error_count_first_step: int, total_error_percent):
        """
        Retrieves Errors list for particular api on particular timing -> query
        Categorization   - if x in y

        unknown errors -        not in any category
        if unknown error  ->  insert to bot satan db

        Retrieves Errors list
        Filter out Ignorable errors and warnings
        On remaining errors calculates error percent and find unknown errors
        Error percent is calculated on distinct errors data
        unknown errors are pushed to db for categorization process

        :param process: for which process calculating percent errors
        :param api: for which api calculating percent errors
        :param lower_time: lower value of epoch time
        :param current_time: current value of epoch time
        :return: 1 if any of threshold condition breaches else 0
        """
        self.logger.CURRENT_API = api
        self.logger.API_LOG = True
        # logger properties changed, a way build to get more clean and robust logs for APIs
        try:
            self.logger.write_logs('info', f'CHECKING ERRORS FOR {api}')
            set_alert = 0
            alert_data = {
                'unknown_errors': "",
                "ignored_errors": "",
                "warnings": "",
                "critical_errors": "",
                "critical_error_percent": 0,
                "total_count_without_ignore": 0,
                "total_count_with_ignore": 0,
                "total_error_percent": 0,
                "total_not_ok_count": 0,
            }
            query = self.query.format(api=api, process=process, lower_time=lower_time, current_time=current_time)

            try:
                mysql_data = self.db_con.query_executor(query).fetchall()
            except Exception:
                self.logger.write_logs('error', f"error while executing query {query}")
                self.logger.write_logs('info', f"quiting process for api {api}, moving towards next api")
                return 0, alert_data
            if not mysql_data:
                self.logger.write_logs('error', f"no data found for api {api} from sql query/procedure")
                return 0, alert_data
            # picking only error strings
            """
            mysql gives 5 columns
            1 - api_name
            2 - no use case
            3 - error text
            4 - error count
            5 - distinct error text
            
            diff b/w 3 and 5
                3 - is all error text additional values like imsi
                5 - is distinct error text 
            
            """

            raw_error_data = [i[2].lower() for i in mysql_data]
            error_count_dict = {i[2].lower(): float(i[3]) for i in mysql_data}
            total_errors_count = sum(list(error_count_dict.values()))
            distinct_error_data = {i[2].lower(): i[4] for i in mysql_data}
            alert_data['total_count_with_ignore'] = total_errors_count
            self.logger.write_logs('info', f" incoming errors : {raw_error_data}")
            if total_errors_count != error_count_first_step:
                self.logger.write_logs('error', f'total error count at first step and second step mismatch '
                                                f': first step {error_count_first_step} : second step {total_errors_count}')

            error_data_dict = {i.lower(): re.sub("[ \t]+", " ", re.sub("[\[\],:\/()\\-{}\"\`.<>?;!@#$%^&*]+", " ", re.sub("\d+", "", i))).lower().strip() for i in raw_error_data}
            error_data_dict = {i: v.replace('\\', '').strip() for i, v in error_data_dict.items()}


            # filtering ignore errors
            error_data_dict = {i: v for i, v in error_data_dict.items() if not v.startswith('retry no')}


            total_errors_count = sum([error_count_dict.get(i, 1) for i, v in error_data_dict.items()])
            self.logger.write_logs('debug', f"second step fetched data length after ignoring ignore_errors : {len(error_data_dict)} : total error count"
                                            f"{total_errors_count}")
            alert_data['total_count_without_ignore'] = total_errors_count

            # till now list also have warnings
            if total_error_percent > 70 and total_errors_count > 10:
                set_alert = 1


            #  filtering warning
            ignore_errors_warnings = self.api_error_instance.fetch_all_warnings(process)

            ignore_errors = [i.lower() for i in ignore_errors_warnings]  # warnings
            ignore_error_data = []
            for raw_error_data, error_data in error_data_dict.items():
                for error in ignore_errors:
                    if self.match_string(error, error_data, raw_error_data): # (registered_error, cleaned_error_data, raw_error)
                        ignore_error_data.append(raw_error_data)
                        try:
                            error_count_dict[raw_error_data]
                        except KeyError as e:
                            self.logger.write_logs('error', f'error count not found for warning : {raw_error_data}')
                        break
            if ignore_error_data:
                alert_data['warnings'] = {i: error_count_dict.get(i, 1) for i in ignore_error_data}
                self.logger.write_logs('debug', f" warnings - {ignore_error_data}")
            else:
                self.logger.write_logs('info', f"no warnings found")

            # filtering main error from warnings
            if ignore_error_data:
                error_data_dict = {i: v for i, v in error_data_dict.items() if i not in ignore_error_data}

            del ignore_error_data, ignore_errors
            if len(error_data_dict) == 0:
                self.logger.write_logs('info', f"length of error list after filtering warnings and ignorable errors 0,"
                                          f" skipping further check process")
                return 0, alert_data

            # threshold_conditions = self.api_error_instance.fetch_threshold_conditions(process, api)
            # example -
            registered_global_errors = self.api_error_instance.fetch_global_errors(process)
            registered_critical_errors = self.api_error_instance.fetch_errors(process, api, 'critical_errors')
            registered_http_errors = self.api_error_instance.fetch_http_errors(process)
            all_category_critical_errors = registered_global_errors + registered_http_errors + registered_critical_errors
            threshold_conditions = {'global_errors+critical_errors+http_errors': 30}
            # changeable for all apis
            # threshold conditions
            # for what actually this is capable for
            # threshold_conditions = self.api_error_instance.fetch_threshold_conditions(process, api)

            registered_errors_list = {'global_errors': registered_global_errors, 'critical_errors': registered_critical_errors,'global_errors+critical_errors+http_errors': all_category_critical_errors}
            # defined error categories dict, instead of picking from database
            count = 0
            unknown_errors = set()

            # finding threshold conditions, according basis of category
            for category, value in threshold_conditions.items():
                count += 1
                error_count = 0
                error_verified_list = registered_errors_list[category]
                error_verified_list = [i.lower() for i in error_verified_list]

                identified_critical_errors = set()
                for raw_error_data, error_data in error_data_dict.items():
                    flag = 1
                    for error in error_verified_list:
                        # checking if error find any match
                        if self.match_string(error, error_data, raw_error_data):
                            identified_critical_errors.add(raw_error_data)
                            # if error is matched then adding error to required group list
                            # making down flag of unknown error
                            # and breaking loop for further iteration
                            try:
                                error_count += error_count_dict[raw_error_data]
                                # increasing error count for particular category
                                self.logger.write_logs('info', f"finding errors count from count dict {error_count_dict[raw_error_data]}")
                            except KeyError:
                                self.logger.write_logs('error', f"Key Error bypassed, couldn't find data in error count dict")
                                error_count += 1
                            flag = 0
                            break
                    if flag:
                        # adding error to unknown errors list if error couldn't find any match with any defined error
                        unknown_errors.add(raw_error_data)

                # as above loop will iterate only for once, so all above data in loop can be used like error_count

                if identified_critical_errors:
                    self.logger.write_logs('debug', f"{category} : matched errors : {identified_critical_errors}")
                else:
                    self.logger.write_logs('info', f"{category} : no matched errors ")
                error_percent = round(error_count * 100 / total_errors_count, 2)

                # checking here alert fire conditions, as defined
                if error_percent >= value and error_count > 5:
                    set_alert = 1
                    self.logger.write_logs('critical', f'threshold crossed : {category} threshold value - {value} : current value {error_percent}',)
                else:
                    self.logger.write_logs('info', f'not crossed threshold : {category} threshold value - {value} : current value {error_percent}',)
                # alert_data["critical_errors"] = {i: error_count_dict.get(i, 1) for i in identified_critical_errors}
                alert_data['critical_error_percent'] = error_percent

                # adding distinct error data from, for showing in teams alert
                represent_critical_errors = dict()
                for error, distinct_error in distinct_error_data.items():
                    if not (error in identified_critical_errors):
                        continue
                    if represent_critical_errors.get(distinct_error):
                        represent_critical_errors[distinct_error] += error_count_dict.get(error, 1)
                    else:
                        represent_critical_errors[distinct_error] = error_count_dict.get(error, 1)
                alert_data["critical_errors"] = represent_critical_errors

            # for counting unknown errors
            if unknown_errors:
                for i in unknown_errors:
                    self.tensorflow_predict(i)
                represent_unknown_errors = dict()
                for error, distinct_error in distinct_error_data.items():
                    if not (error in unknown_errors):
                        continue
                    if represent_unknown_errors.get(distinct_error):
                        represent_unknown_errors[distinct_error] += error_count_dict.get(error, 1)
                    else:
                        represent_unknown_errors[distinct_error] = error_count_dict.get(error, 1)

                # adding unknown errors to alert data
                alert_data["unknown_errors"] = represent_unknown_errors
                # alert_data['unknown_errors'] = {i: error_count_dict.get(i, 1) for i in unknown_errors}
                self.logger.write_logs('critical', f'unknown-errors : data - {unknown_errors}')
                unknown_errors_count = sum([error_count_dict.get(i, 1) for i in unknown_errors])
                current_date_time = datetime.utcfromtimestamp(int(current_time)).strftime('%Y-%m-%d %H:%M:%S')

                # inserting unknown errors to api_error_config_db, the main control db of bot satan
                self.api_error_instance.insert_unknown_errors(process, api, unknown_errors, error_count_dict, unknown_errors_count, epoch_time=current_time,
                                                              date_time=current_date_time)
                unknown_errors_percent = unknown_errors_count * 100 / total_errors_count
                self.logger.write_logs('critical', f'unknown-errors percent - {unknown_errors_percent}:  total - {unknown_errors_count} : distinct count - {len(unknown_errors)}')
            else:
                self.logger.write_logs('info', 'no unknown errors were recorded')
            return set_alert, alert_data
        except Exception as e:
            self.logger.write_logs('error', f"error occurred in downstream method {e}")
        finally:
            self.logger.CURRENT_API = None
            self.logger.API_LOG = False

