"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Last Modified : 2021-06-25

> summary : API Error percent calculation first step, find overall error percent of api if threshold breaches then goes
            to second step.
"""


from os.path import isfile
import json
from influx import InfluxDB
import mysql.connector
import pymsteams

from datetime import datetime, timedelta

from logger.logger import get_logger
from api_error_logger import Logger
from db_connection import DBConnection
from detailed_error_checker import ErrorsCatcher
from webhook_notification import send_teams_channel_notification, send_unknown_notification

from webhook_notification import send_teams_channel_notification
from api_error_mysql.api_error_mysql import APIErrorDBClass
DATABASE = measurment = client = logger = db_con = current_time = lower_time = error_catcher = None


try:
    """
    initializing false instances to get help in IDE 
    """

    logger = Logger()
    error_catcher = ErrorsCatcher()
    db_con = DBConnection()

    current_time = lower_time = datetime.utcnow() - timedelta(hours=1)

    lower_time = lower_time.strftime('%s')
    current_time = current_time.strftime('%s')

    client = InfluxDB('http://127.0.0.1:8086')
    DATABASE = 'matrics'
    measurment = 'nb_timeout_error'
except Exception:
    pass


def insert_to_influx(error_percent, success_count, fail_count, is_alert, process,  api, alert_data, grafana_dashboards):
    """
    :param error_percent: error_percent
    :param success_count: success_count
    :param fail_count: fail_count
    :param is_alert: is_alert
    :param process: process
    :param api: api

    function to insert data in influx and generate alert
    """
    push_notification = False
    try:
        # fetching previous alert bit and error percent for particular api
        # fetching - alert_bit, error_percent
        alert_influx_data = client.select_where(DATABASE, measurment, fields='is_alert,error_percent', tags={'api_name': api},
                                         where='time > 0', desc=True, limit=1)
        # alert_data = client.select_where(DATABASE, measurment, fields='is_alert', tags={'api_name': api}, desc=True, limit=1)
        logger.write_logs('info', f"API {api} : alert_data {alert_influx_data}")
        is_alert_prv = alert_influx_data['results'][0]['series'][0]['values'][0][1]
        error_percent_prv = alert_influx_data['results'][0]['series'][0]['values'][0][2]
        logger.write_logs('info', f"API {api} :successfully retrieved alert bit")
    except Exception as e:
        # if any error comes for fetching
        # then it means there is no data for particular api
        # so we assume
        #               alert_bit = 0
        #               error_percent = 0
        logger.write_logs('warning', f"API {api} :failed while fetching previous alert bit from influx")
        is_alert_prv = 0
        error_percent_prv = 0

    """
    Now there are 2 things
        1. keep record of alert bit
        2. push notification to teams
        
        1. keep record of alert bit
                case matrix
                prev_alert    new_alert    keep record
                1              0            yes
                1              1            yes
                0              1            yes
                0              0            no
                
                
        2. push notifications to teams on basis of alert bits
        
            case matrix
            prev_alert          new_alert         new_error_percent > previous_error_percent      push_notification_teams
            0                       0                       True/False                                  no
            0                       1                       True/False                                  yes
            1                       0                       True/False                                  yes
            1                       1                         True                                      yes
            1                       1                         False                                     no
    """

    # push notification to teams
    if is_alert_prv != is_alert:
        push_notification = True
    elif (is_alert_prv == is_alert == 1) and error_percent > error_percent_prv:
        push_notification = True

    logger.write_logs('debug', f" API {api} : ALERT DATA {alert_data}")
    try:
        webhook_url = grafana_dashboards['webhook_url']
        unknown_webhook_url = grafana_dashboards['unknown_webhook_url']

        error_details_dashboard = grafana_dashboards['error_details_dashboard']
        error_percent_dashboard = grafana_dashboards['error_percent_dashboard']
        error_details_dashboard = error_details_dashboard.format(api=api.title().replace(' ', '%20'),
                                                                 lower_time=lower_time,
                                                                 current_time=current_time)
        error_percent_dashboard = error_percent_dashboard.format(api=api.title(), lower_time=lower_time,
                                                                 current_time=current_time)
        # todo later below written
        api_error_instance = APIErrorDBClass(logger)
        uuid = api_error_instance.api_error_status(process, api, is_alert, current_time, logger)

        if grafana_dashboards and push_notification:
            # todo later in detail for now just simple use case explained
            send_teams_channel_notification(is_alert, process, api, alert_data, error_percent_dashboard, error_details_dashboard, webhook_url, uuid)
        if alert_data["unknown_errors"]:
            send_unknown_notification(process, api, alert_data, error_percent_dashboard, error_details_dashboard,
                                      unknown_webhook_url)
    except Exception as e:
        logger.write_logs('error', f"error while pushing msteams alerts : {e}")

    # keep record of alert bit in influx db
    if not (is_alert_prv == is_alert == 0):
        client.write_many(DATABASE, measurment,
                      fields=['error_percent', 'success_count', 'fail_count', 'is_alert'],
                      values=[[error_percent, success_count, fail_count, is_alert]],
                      tags={'api_name': api})
        logger.write_logs('info', f'inserted to influx   : API  {api} : alert bit {is_alert}: '
                                  f'error_percent {error_percent} : fail_count {fail_count}: total count {success_count+fail_count}')


def mysql_to_tsdb_write(process, apis, query, grafana_dashboards, **process_kwargs):
    """
    First step of error checking
    if first threshold condition breaches then goes to second inner categorized error checking

    call to insert influx method and insert check result to influx

    :param process: on what errors need to be checked
    :param apis: apis dict with their threshold values on what errors need to be checked
    :param query: query to execute in mysql database to fetch error logs from certain time limit
    """
    global current_time, lower_time
    query = query.format(lower_time=lower_time, current_time=current_time)
    try:
        mysql_data = db_con.query_executor(query).fetchall()
    except Exception as e:
        logger.write_logs('error', f'error occurred : {e} while executing query {query}')
        exit(1)
    logger.write_logs('info', f"received data len {len(mysql_data)}")
    # max_depth_check = process_kwargs.get('max_depth_check')

    for i in mysql_data:
        api, _, *counts = i
        api = str(api).lower()
        try:
            ok_count, not_ok_count, total_count = map(float, counts)
        except Exception as e:
            logger.write_logs('error', f'error while parsing data : received data for ok_count, not_ok_count, total_count {counts}')
            logger.write_logs('warning', f'quiting process further.')
            exit(1)
        error_percent = not_ok_count / total_count * 100 if total_count else 0


        # if max_depth_check and max_depth_check == 1:
        #     is_alert = 1 if (error_percent >= process_kwargs['on_error_percent_threshold'] or total_count >= process_kwargs['on_total_threshold']) else 0
        #     alert_data = {
        #         # 'unknown_errors': "",
        #         # "ignored_errors": "",
        #         # "warnings": "",
        #         "critical_errors": {},
        #         "critical_error_percent": error_percent,
        #         "total_count_without_ignore": not_ok_count,
        #         "total_count_with_ignore": total_count,
        #         "total_error_percent": error_percent,
        #         "total_not_ok_count": not_ok_count,
        #     }
        #     insert_to_influx(error_percent, ok_count, not_ok_count, is_alert, process, api, alert_data,
        #                      grafana_dashboards)
        #
        #     continue

        apis = {i.lower(): v for i, v in apis.items()}
        # if is_alert == 0 and api.lower() in apis:
        if api in apis:
            # logger.write_logs('debug', f"API {api} : error_percent - {error_percent} : not_ok_count - {not_ok_count} : "
            #                            f"ok_count {ok_count} : total_count {total_count}")

            detailed_error_check_result = False
            """
            maybe what errors are coming they are false errors like -  ignorable errors or warnings
            
            errors - category - 
                ignorable
                warning
                critical
                http
                global
                        
            
            
            """
            alert_data = {
                'unknown_errors': "",
                "ignored_errors": "",
                "warnings": "",
                "critical_errors": "",
                "critical_error_percent": 0,
                "total_count_without_ignore": 0,
                "total_count_with_ignore": 0,
                "total_error_percent": 0,
                "total_not_ok_count": 0,
            }
            if error_percent:
                # todo later check code flow of below line later on
                detailed_error_check_result, alert_data = error_catcher.check_downstream_system_error(process, api, lower_time, current_time, not_ok_count, error_percent)

            is_alert = 0
            if error_percent > apis[api] and not_ok_count > 10 and detailed_error_check_result:
                # todo place first_check_min_error and second_step_min_error instead of >1
                    is_alert = 1

            if is_alert:
                logger.write_logs('debug',
                                  f"API {api} : error_percent - {error_percent} : not_ok_count - {not_ok_count} : "
                                  f"ok_count {ok_count} : total_count {total_count} : is_alert 1")

            else:
                logger.write_logs('info',
                                  f"API {api} : error_percent - {error_percent} : not_ok_count - {not_ok_count} : "
                                  f"ok_count {ok_count} : total_count {total_count} : is_alert 0")
            alert_data['total_error_percent'] = error_percent
            alert_data['total_not_ok_count'] = not_ok_count
            insert_to_influx(error_percent, ok_count, not_ok_count, is_alert, process, api, alert_data, grafana_dashboards)


def process_starter(influx_db_config, mysql_db_config, process, apis, log_file_base_path, log_file_name,
                    query_stage_1, query_stage_2, _lower_time=None, _current_time=None, text_match_log_file=None,
                    grafana_dashboards=None, **process_kwargs):
    """
    function to initialize all required instances and then start api checker process
    """
    global client, DATABASE, measurment, db_con, logger, error_catcher, current_time, lower_time
    client = InfluxDB(influx_db_config['host'])
    DATABASE = influx_db_config['database']
    measurment = influx_db_config['measurment']
    unknown_error_measurement = influx_db_config['dev_unknown_error_measurement']

    logger = Logger(log_file_base_path, log_file_name)
    logger.write_logs('info', f'text_match_log_file PATH : {text_match_log_file}')




    # error's text   ->   in which category
                        # sample error list according to category
                        # algos to find match on text
    error_text_match_file = None
    if text_match_log_file and not isfile(f"./{text_match_log_file}"):
        logger.write_logs('info', f'text_match_log_file : creating file')
        error_text_match_file = open(text_match_log_file, 'a')
        pattern = "registered_error|error|exist_in_error|exist_in_raw_error|ratio|" \
                  "partial_ratio|cosine|levenshtein|" \
                  "jaro_winkler|trigram|" \
                  "sequence_matcher"
        error_text_match_file.write(pattern)
    elif text_match_log_file and isfile(f"./{text_match_log_file}"):
        logger.write_logs('info', f'text_match_log_file : picking previous file')
        error_text_match_file = open(text_match_log_file, 'a')
    else:
        logger.write_logs('info', f'text_match_log_file : doing nothing')




    # ERROR CATEGORIZATION -  Tensorflow
    tensorflow_prediction_log = None
    if process.lower() in ['nb', 'sb']:
        tensorflow_prediction_file = f"./tensorflow_prediction_{process}.csv"
        if not isfile(tensorflow_prediction_file):
            tensorflow_prediction_log = open(tensorflow_prediction_file, 'a')
            pattern = "timestamp|error|prediction"
            tensorflow_prediction_log.write(pattern)
        else:
            tensorflow_prediction_log = open(tensorflow_prediction_file, 'a')


    "logger, cronjob, "

    print('creating db connection')
    db_con = DBConnection(mysql_db_config, logger)
    print('db connection created')

    error_catcher = ErrorsCatcher(query_stage_2, error_text_match_file, logger, db_con, client, DATABASE, unknown_error_measurement,
                                  grafana_dashboards, tensorflow_prediction_log)

    # for production
    # to calculate automatically
    # on time basis when script will execute
    current_time = datetime.utcnow() - timedelta(hours=0)
    lower_time = datetime.utcnow() - timedelta(hours=1)
    logger.write_logs('info', f"running for time  from -{lower_time} to {current_time}")

    # for testing
    # when script is needed to execute for some previous time
    # to check some error if there is for error of particular timing
    lower_time = lower_time.strftime('%s')
    current_time = current_time.strftime('%s')
    if _current_time and _lower_time:
        current_time = _current_time
        lower_time = _lower_time
    logger.write_logs('info', f"epoch time range : {lower_time} to {current_time}")
    # initializing error checker process
    mysql_to_tsdb_write(process, apis, query_stage_1, grafana_dashboards, **process_kwargs)
    if error_text_match_file:
        error_text_match_file.close()
    if tensorflow_prediction_log:
        tensorflow_prediction_log.close()
    logger.write_logs('info', "script executed successfully.")

