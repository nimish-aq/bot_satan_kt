"""
> Project name : BOT SATAN
> Author name : Amandeep Singh
> Project version : 1.0.1
> Project language : python
> Last Modified : 2021-11-08

> summary : module script take a runs with cronjob with 15 min time interval, fetches records Influx and push alerting
 notifications to teams channel.

    Similar working as previous script influx_to_teams_notification.py,
    previous script fetches data from kafka_lag_measurement, in which data of kafka is directly pushed

    this script fetches data from kafka_measurement, in which data pushed from kafka log files

"""

from influx import InfluxDB
import pymsteams
import pandas as pd
import traceback


db = 'matrics'

measurement = 'kafka_measurement'

host_main = 'http://10.221.86.30:8086'
local_host = 'http://127.0.0.1:8086'

client = InfluxDB(local_host)
previous_rs = client.select_where(db, measurement, where=f'time > now() - 30m and time < now() - 15m')
current_rs = client.select_where(db, measurement, where=f'time > now() -15m')
# make it on some difference not with 5 min


# previous_rs = {'results': [{'statement_id': 0, 'series': [{'name': 'kafka_lag_measurement', 'columns': ['time', 'flag', 'group', 'lag_value', 'topic'], 'values': [[1635422703804998, 1, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 4'], [1635422703811852, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 8'], [1635422703816455, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 3'], [1635422703821413, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 0'], [1635422703826012, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 7'], [1635422703830326, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 2'], [1635422703834398, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 6'], [1635422703838721, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 5'], [1635422703842872, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 1'], [1635422705690150, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 4'], [1635422705696680, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 8'], [1635422705701527, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 3'], [1635422705706978, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 0'], [1635422705711543, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 7'], [1635422705715997, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 2'], [1635422705720263, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 6'], [1635422705724496, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 5'], [1635422705729940, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 1'], [1635422707914702, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 4'], [1635422707921196, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 8'], [1635422707925480, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 3'], [1635422707929997, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 0'], [1635422707934105, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 7'], [1635422707938738, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 2'], [1635422707943539, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 6'], [1635422707947955, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 5'], [1635422707954049, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 1'], [1635422710184998, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 4'], [1635422710194186, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 8'], [1635422710202903, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 3'], [1635422710211012, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 0'], [1635422710218035, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 7'], [1635422710222798, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 2'], [1635422710227267, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 6'], [1635422710231829, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 5'], [1635422710236198, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 1'], [1635422712057308, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 4'], [1635422712064605, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 8'], [1635422712069148, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 3'], [1635422712072979, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 0'], [1635422712077123, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 7'], [1635422712081003, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 2'], [1635422712084851, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 6'], [1635422712088944, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 1, 'Request_Topic_nb 5'], [1635422712092886, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 1'], [1635422713899994, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 4'], [1635422713906067, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 8'], [1635422713910103, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 3'], [1635422713914445, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 0'], [1635422713918527, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 7'], [1635422713922594, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 2'], [1635422713926583, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 6'], [1635422713930384, 0, 'orchastration_consumer_api_GMSA_sb_2', 1, 'Request_Topic_nb 5'], [1635422713934234, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 1'], [1635423003452146, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 4'], [1635423003460106, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 8'], [1635423003464782, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 3'], [1635423003469624, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 0'], [1635423003474057, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 7'], [1635423003478383, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 2'], [1635423003482364, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 6'], [1635423003486693, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 5'], [1635423003491232, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 1'], [1635423005416199, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 4'], [1635423005424121, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 8'], [1635423005428811, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 3'], [1635423005433733, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 0'], [1635423005437821, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 7'], [1635423005443006, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 2'], [1635423005447493, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 6'], [1635423005451651, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 5'], [1635423005455718, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 1'], [1635423007376905, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 4'], [1635423007384010, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 8'], [1635423007389855, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 3'], [1635423007394658, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 0'], [1635423007399289, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 7'], [1635423007404134, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 2'], [1635423007408749, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 6'], [1635423007413427, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 5'], [1635423007417573, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 1'], [1635423009271375, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 4'], [1635423009284749, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 8'], [1635423009288986, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 3'], [1635423009293136, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 0'], [1635423009297610, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 7'], [1635423009301537, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 2'], [1635423009305212, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 6'], [1635423009309182, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 5'], [1635423009313840, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 1'], [1635423011187319, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 4'], [1635423011194086, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 8'], [1635423011198294, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 3'], [1635423011202975, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 0'], [1635423011206917, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 7'], [1635423011211505, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 2'], [1635423011215670, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 6'], [1635423011219725, 1, 'GMSA_Orchastration_Engine_Notify_Limit_1', 1, 'Request_Topic_nb 5'], [1635423011224055, 1, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 1'], [1635423013054762, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 4'], [1635423013061886, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 8'], [1635423013066577, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 3'], [1635423013070917, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 0'], [1635423013075176, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 7'], [1635423013079160, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 2'], [1635423013083500, 1, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 6'], [1635423013087714, 0, 'orchastration_consumer_api_GMSA_sb_2', 1, 'Request_Topic_nb 5'], [1635423013095073, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 1']]}]}]}
# current_rs = {'results': [{'statement_id': 0, 'series': [{'name': 'kafka_lag_measurement', 'columns': ['time', 'flag', 'group', 'lag_value', 'topic'], 'values': [[1635422703804998, 1, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 4'], [1635422703811852, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 8'], [1635422703816455, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 3'], [1635422703821413, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 0'], [1635422703826012, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 7'], [1635422703830326, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 2'], [1635422703834398, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 6'], [1635422703838721, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 5'], [1635422703842872, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 1'], [1635422705690150, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 4'], [1635422705696680, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 8'], [1635422705701527, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 3'], [1635422705706978, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 0'], [1635422705711543, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 7'], [1635422705715997, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 2'], [1635422705720263, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 6'], [1635422705724496, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 5'], [1635422705729940, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 1'], [1635422707914702, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 4'], [1635422707921196, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 8'], [1635422707925480, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 3'], [1635422707929997, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 0'], [1635422707934105, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 7'], [1635422707938738, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 2'], [1635422707943539, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 6'], [1635422707947955, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 5'], [1635422707954049, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 1'], [1635422710184998, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 4'], [1635422710194186, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 8'], [1635422710202903, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 3'], [1635422710211012, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 0'], [1635422710218035, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 7'], [1635422710222798, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 2'], [1635422710227267, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 6'], [1635422710231829, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 5'], [1635422710236198, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 1'], [1635422712057308, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 4'], [1635422712064605, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 8'], [1635422712069148, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 3'], [1635422712072979, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 0'], [1635422712077123, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 7'], [1635422712081003, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 2'], [1635422712084851, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 6'], [1635422712088944, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 1, 'Request_Topic_nb 5'], [1635422712092886, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 1'], [1635422713899994, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 4'], [1635422713906067, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 8'], [1635422713910103, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 3'], [1635422713914445, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 0'], [1635422713918527, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 7'], [1635422713922594, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 2'], [1635422713926583, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 6'], [1635422713930384, 0, 'orchastration_consumer_api_GMSA_sb_2', 1, 'Request_Topic_nb 5'], [1635422713934234, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 1'], [1635423003452146, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 4'], [1635423003460106, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 8'], [1635423003464782, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 3'], [1635423003469624, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 0'], [1635423003474057, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 7'], [1635423003478383, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 2'], [1635423003482364, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 6'], [1635423003486693, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 5'], [1635423003491232, 0, 'orchastration_consumer_api_GMSA_nb_1', 0, 'Request_Topic_nb 1'], [1635423005416199, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 4'], [1635423005424121, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 8'], [1635423005428811, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 3'], [1635423005433733, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 0'], [1635423005437821, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 7'], [1635423005443006, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 2'], [1635423005447493, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 6'], [1635423005451651, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 5'], [1635423005455718, 0, 'orchastration_consumer_api_GMSA_uds_1', 0, 'Request_Topic_nb 1'], [1635423007376905, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 4'], [1635423007384010, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 8'], [1635423007389855, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 3'], [1635423007394658, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 0'], [1635423007399289, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 7'], [1635423007404134, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 2'], [1635423007408749, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 6'], [1635423007413427, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 5'], [1635423007417573, 0, 'orchastration_consumer_api_GMSA_nb_add1', 0, 'Request_Topic_nb 1'], [1635423009271375, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 4'], [1635423009284749, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 8'], [1635423009288986, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 3'], [1635423009293136, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 0'], [1635423009297610, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 7'], [1635423009301537, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 2'], [1635423009305212, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 6'], [1635423009309182, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 5'], [1635423009313840, 0, 'GMSA_Orchastration_Engine_Onboarding_1', 0, 'Request_Topic_nb 1'], [1635423011187319, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 4'], [1635423011194086, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 8'], [1635423011198294, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 3'], [1635423011202975, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 0'], [1635423011206917, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 7'], [1635423011211505, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 2'], [1635423011215670, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 6'], [1635423011219725, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 1, 'Request_Topic_nb 5'], [1635423011224055, 0, 'GMSA_Orchastration_Engine_Notify_Limit_1', 0, 'Request_Topic_nb 1'], [1635423013054762, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 4'], [1635423013061886, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 8'], [1635423013066577, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 3'], [1635423013070917, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 0'], [1635423013075176, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 7'], [1635423013079160, 0, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 2'], [1635423013083500, 1, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 6'], [1635423013087714, 0, 'orchastration_consumer_api_GMSA_sb_2', 1, 'Request_Topic_nb 5'], [1635423013095073, 1, 'orchastration_consumer_api_GMSA_sb_2', 0, 'Request_Topic_nb 1']]}]}]}


def get_alerts_data(sample_data):
    try:
        df = pd.DataFrame(data=sample_data['results'][0]['series'][0]['values'], columns=sample_data['results'][0]['series'][0]['columns'])
        group_bys_list = df['api'].unique()
        reversed_df = df.sort_values('time', ascending=[False])

        alert_groups = set()
        alert_data = []

        # looking for current alert one
        for group in group_bys_list:
            temp_df = reversed_df[reversed_df['api'] == group]
            if temp_df.iloc[0]['flag'] == 1:
                alert_data.append(list(temp_df.iloc[0]))
                alert_groups.add(group)

        return alert_groups, alert_data
    except Exception as e:
        print("Error is : ", e)
        print("Traceback is : ",  traceback.format_exc())
        return set(), []


def send_teams_channel_notification(is_alert, process, apis, alert_data, error_percent_dashboard, webhook_url):
    process = process.upper()
    myTeamsMessage = pymsteams.connectorcard(webhook_url)

    if is_alert:
        myTeamsMessage.title("[Alerting] OL %s " % (process))
        myTeamsMessage.color("#FF0000")
    else:
        myTeamsMessage.title("[Clear] OL %s " % (process))
        myTeamsMessage.color("#228B22")
    message_dict = {0: "Closed alert for OL %s" % (process),
                    1: "ALERT!!!!Monitoring Bot has figured out more failures for OL %s in Last 5 min.To see details of error please check below links and error details : " % (
                        process)}

    myTeamsMessage.text(message_dict[is_alert])
    if is_alert:
        for x in alert_data:
            myMessageSection = pymsteams.cardsection()
            alert_data_columns = ['time', 'API', 'flag',  'output']
            myMessageSection.title(f" Consumer Group's Error Details")
            myMessageSection.addFact("Consumer Group ", str(x[1]))
            myMessageSection.addFact("Output", str(x[3]))
            myTeamsMessage.addSection(myMessageSection)
    else:
        myMessageSection = pymsteams.cardsection()
        myMessageSection.title("Closed Alert for below apis")
        for _count, x in enumerate(apis, start=1):
            myMessageSection.addFact(f"{_count}", str(x))
        myTeamsMessage.addSection(myMessageSection)

    myMessageSection = pymsteams.cardsection()
    myMessageSection.title("Detail Links")
    myMessageSection.addFact("Error Percent Dashboard", error_percent_dashboard)
    # myMessageSection.addFact("Error Detail Dashboard", error_details_dashboard)

    if is_alert:
        myMessageSection.title("Note")
        myMessageSection.text(
            "This Alert will be automatically closed as soon lag value falls below defined threshold")
        myTeamsMessage.addSection(myMessageSection)
    myTeamsMessage.send()


alert_data_columns = ['time', 'alert_bit', 'API', 'LAG_VALUE', 'TOPIC']
current_alert_groups, current_alert_data = get_alerts_data(current_rs)
previous_alert_groups, _ = get_alerts_data(previous_rs)
cleared_alert_groups = previous_alert_groups - current_alert_groups


process = "Kafka File Logs "
#webhook_url = 'https://globetouch1.webhook.office.com/webhookb2/264a56f2-0529-4995-9c3d-d2cc84abcfe5@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/85358df8625640ce91118b56133a735f/83df8e4c-fc16-4b73-b9cc-a460ea7d55f5'

webhook_url = 'https://globetouch1.webhook.office.com/webhookb2/09ad3ce3-bd62-42c1-801a-0f32ae9116e2@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/d8e6f9cddda24b5ab54947a590daa70a/3e1ee893-36e1-435d-bd99-312b73e28b94'
error_percent_dashboard = 'https://grafana.airlinq.com:3000/d/5Ay_KZFnz/gmsa-queue-and-misc-alerts?tab=queries&panelId=6&edit&fullscreen&orgId=6'


# test webhook url
# webhook_url = 'https://globetouch1.webhook.office.com/webhookb2/14246241-ddd8-4c60-a880-01de89269d88@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/f1b07c12ec8348fe8e78c4acaffbca1d/149a3ac7-049f-4937-9223-9093ba97924c'

# print('current_alert_data ', current_alert_data)
# print('cleared_alert_groups ', cleared_alert_groups)
# exit(0)


if current_alert_data:
    send_teams_channel_notification(1,process,  set(), current_alert_data, error_percent_dashboard, webhook_url)
if cleared_alert_groups:
    send_teams_channel_notification(0, process,  cleared_alert_groups, [], error_percent_dashboard, webhook_url)

print('script success')
