import logging
from os.path import isfile, join, dirname


def get_logger(log_file_base_path, log_file_name):
    file_path = join(dirname(dirname(__file__)), log_file_name)

    # print(log_file_base_path + log_file_name)
    # if not isfile(log_file_base_path + log_file_name):
    #     f = open(file=log_file_base_path+log_file_name, mode='w+')
    #     f.close()
    aq_logger = logging.getLogger(f'log_file_name')
    logging.basicConfig(filename=file_path,
                        format='%(asctime)s - %(levelname)s : %(message)s',
                        filemode='a')

    # Setting the threshold of aq_logger to DEBUG
    aq_logger.setLevel(logging.DEBUG)
    return aq_logger
