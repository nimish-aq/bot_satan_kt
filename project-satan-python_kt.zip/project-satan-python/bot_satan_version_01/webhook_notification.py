"""
Python Script to manage MS Teams notification template
Written By : Amandeep Singh
Design Update : July 13, 2021 [Siddhika Nag]
Updated By: Amandeep Singh

Usage Summery :- Teams Notification sending method, for BOT SATAN main process.


"""
import re

import pymsteams


def send_unknown_notification(process, api, alert_data, error_percent_dashboard, error_details_dashboard, webhook_url):
    """
    Function for uncategorized error template

    Parameters
    -----------
    process : NB/SB
    api : API for which error is traced
    alert_data : Python Dictionary with error details, eg
                 {
                        "unknown_errors": "",
                        "ignored_errors": "",
                        "warnings":{"resource not found": 96.0},
                        "critical_errors": {"resource not found": 96.0},
                        "total_count_without_ignore": 96.0,
                        "total_count_with_ignore": 96.0,
                        "critical_error_percent": 100.0,
                        "total_error_percent": 75.0,
                        "total_not_ok_count": 6.0
                  }
    error_percent_dashboard : Grafana Error Stats Dashboard Link
    error_details_dashboard : Grafana Error Details Dashboard Links
    webhook_url : MS Teams Channels connector webhook URL

    Returns
    -------
    NA

    """
    myTeamsMessage = pymsteams.connectorcard(webhook_url)
    myTeamsMessage.title("[Unknown Error] %s %s " % (process, api))
    myTeamsMessage.color("#FFA500")
    myTeamsMessage.text(
        "ALERT!!!!Monitoring Bot has figured out uncategorized failures for OL %s %s in Last 1 hour..To see details of error please check below error details : " % (
        process, api))

    myMessageSection = pymsteams.cardsection()
    myMessageSection.title("Detail Links")
    myMessageSection.addFact("Error Percent Dashboard", error_percent_dashboard)
    myMessageSection.addFact("Error Detail Dashboard", error_details_dashboard)
    if process == 'NB':
        myMessageSection.addFact("M&D Dashboard", "https://aircontrol-gmsa.airlinq.com/APIDashboard")
    myTeamsMessage.addSection(myMessageSection)

    def add_errors_details(error_category):
        if alert_data[error_category]:
            myMessageSection = pymsteams.cardsection()
            myMessageSection.title(error_category.replace('_', ' ').title())
            alert_data[error_category] = dict(sorted(alert_data[error_category].items(), key=lambda x: x[1], reverse=True))
            high_errors_flag = 0
            _count = 0
            for error, count in alert_data[error_category].items():
                _count += 1
                if _count > 8:
                    high_errors_flag = 1
                    break
                myMessageSection.addFact(int(count), error)
            if high_errors_flag:
                myMessageSection.addFact('Note - ', 'unknown errors are more then what you see here, '
                                                    'please go through grafana dashboard to see full details.')
            myTeamsMessage.addSection(myMessageSection)

    add_errors_details('unknown_errors')
    myTeamsMessage.send()


def send_teams_channel_notification(is_alert, process, api, alert_data, error_percent_dashboard, error_details_dashboard, webhook_url, uuid, webhook_url_2=None):
    """
    Function for Critical/Clear error template

    Parameters
    -----------
    is_alert : 0/1 Signify wheather alerting condition has met or is cleared
    process : NB/SB
    api : API for which error is traced
    alert_data : Python Dictionary with error details, eg
                 {
                        "unknown_errors": "",
                        "ignored_errors": "",
                        "warnings":{"resource not found": 96.0},
                        "critical_errors": {"resource not found": 96.0},
                        "total_count_without_ignore": 96.0,
                        "total_count_with_ignore": 96.0,
                        "critical_error_percent": 100.0,
                        "total_error_percent": 75.0,
                        "total_not_ok_count": 6.0
                  }
    error_percent_dashboard : Grafana Error Stats Dashboard Link
    error_details_dashboard : Grafana Error Details Dashboard Links
    webhook_url/webhook_url_2 : MS Teams Channels connector webhook URL

    Returns
    -------
    NA

    """

    process = process.upper()
    api = api.upper()
    myTeamsMessage = pymsteams.connectorcard(webhook_url)
    if webhook_url_2:
        myTeamsMessage.newhookurl(webhook_url_2)

    if is_alert:
        myTeamsMessage.title("[Alerting] OL %s %s [%s]" % (process, api, uuid))
        myTeamsMessage.color("#FF0000")
    else:
        myTeamsMessage.title("[Clear] OL %s %s [%s]" % (process, api, uuid))
        myTeamsMessage.color("#228B22")
    message_dict = {0: "Closed alert for OL %s %s" % (process, api),
                    1: "ALERT!!!!Monitoring Bot has figured out more failures for OL %s %s in Last 1 hour.To see details of error please check below links and error details : " % (
                    process, api)}
    myTeamsMessage.text(message_dict[is_alert])
    if is_alert:
         myMessageSection = pymsteams.cardsection()
         myMessageSection.title("Error Stats")
         myMessageSection.addFact("Error Percent [Of Total]", "%s %%" % round(alert_data['total_error_percent'], 2))
         myMessageSection.addFact("Error Count", alert_data['total_count_without_ignore'])
         myMessageSection.addFact("Critical Error Percent","%s %%"% round(alert_data['critical_error_percent']))
         critical_errors_count = sum(list(alert_data['critical_errors'].values())) if alert_data['critical_errors'] else 0
         myMessageSection.addFact("Critical Error Count", critical_errors_count)
         myTeamsMessage.addSection(myMessageSection)

    # create the section
    myMessageSection = pymsteams.cardsection()
    myMessageSection.title("Detail Links")
    myMessageSection.addFact("Error Percent Dashboard", error_percent_dashboard)
    myMessageSection.addFact("Error Detail Dashboard", error_details_dashboard)
    if process == 'NB':
        myMessageSection.addFact("M&D Dashboard", "https://aircontrol-gmsa.airlinq.com/APIDashboard")
    myTeamsMessage.addSection(myMessageSection)
    if is_alert:
        def add_errors_details(error_category):
            if alert_data[error_category]:
                myMessageSection = pymsteams.cardsection()
                myMessageSection.title(error_category.replace('_', ' ').title())
                alert_data[error_category] = dict(sorted(alert_data[error_category].items(), key=lambda x: x[1], reverse=True))
                high_errors_flag = 0
                _count = 0
                for error, count in alert_data[error_category].items():
                    _count += 1
                    if _count > 8:
                        high_errors_flag = 1
                        break
                    myMessageSection.addFact(int(count), error)
                if high_errors_flag:
                    myMessageSection.addFact('Note - ', 'critical errors are more then what you see here, '
                                                        'please go through grafana dashboard to see full details.')
                myTeamsMessage.addSection(myMessageSection)

        add_errors_details('critical_errors')
        # add_errors_details('warnings')
        # add_errors_details('unknown_errors')
        # add_errors_details('ignored_errors')
        myMessageSection = pymsteams.cardsection()
        myMessageSection.title("Note")
        myMessageSection.text(
            "This Alert will be automatically closed as soon error rate falls below defined percentage")
        myTeamsMessage.addSection(myMessageSection)
    """
    myMessageSection = pymsteams.cardsection()
    myMessageSection.title("OverView")
    myMessageSection.addFact("Critical Error Percent", alert_data['critical_error_percent'])
    myMessageSection.addFact("Critical Error Count", alert_data['total_count_without_ignore'])
    myTeamsMessage.addSection(myMessageSection)
    """
    myTeamsMessage.send()

"""
# Dev Testing
#webhook_url = "https://globetouch1.webhook.office.com/webhookb2/14246241-ddd8-4c60-a880-01de89269d88@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/f1b07c12ec8348fe8e78c4acaffbca1d/149a3ac7-049f-4937-9223-9093ba97924c"
webhook_url = "https://globetouch1.webhook.office.com/webhookb2/14246241-ddd8-4c60-a880-01de89269d88@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/f1b07c12ec8348fe8e78c4acaffbca1d/149a3ac7-049f-4937-9223-9093ba97924c"
#webhook_url = "https://globetouch1.webhook.office.com/webhookb2/264a56f2-0529-4995-9c3d-d2cc84abcfe5@c56adddc-8415-4908-a6a8-0ada795e0a9d/IncomingWebhook/79dd459032a34fd98dcacb9d4a83b1ec/83df8e4c-fc16-4b73-b9cc-a460ea7d55f5"
alert_data = {
    "unknown_errors": "", 
    "ignored_errors": "", 
    "warnings": "",
    "critical_errors": {"resource not found": 96.0}, 
    "total_count_without_ignore": 100.0,
    "total_count_with_ignore": 100.0,
    "critical_error_percent": 100.0,
    "total_error_percent": 75.0,
    "total_not_ok_count": 6.0
    }
is_alert = 1
process = 'nb'
api = 'add order'
error_percent_dashboard = "https://gitdhub.com/rveachkc/pymsteams/"
error_details_dashboard = "https://githudb.com/rveachkc/pymsteams/"
# send_teams_channel_notification(is_alert, process, api, alert_data, error_percent_dashboard, error_details_dashboard, webhook_url, 'uuid-uuid-uuid')
"""