
from influx import InfluxDB
import pymsteams
import pandas as pd
import traceback


db = 'matrics'

mt = 'group_by_test'

host_main = 'http://10.221.86.30:8086'
# local_host = 'http://127.0.0.1:8086'

client = InfluxDB(host_main)
client.write_many(db, mt,
                  fields=['error_percent', 'success_count', 'fail_count', 'is_alert'],
                  values=[[20, 20, 20, 0], [20, 20, 20, 1], [20, 20, 20, 20]],
                  tags={'api_name': "api", "collection_name": "abcs"})
