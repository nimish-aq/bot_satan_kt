from pprint import pprint

from influxdb import InfluxDBClient
import pdb


client = InfluxDBClient("10.221.86.30", 8086, database='matrics',)

dict_format = {"source": "", "api": "", "group": "", "topic": "", "error_percent_dashboard": "",
               "error_details_dashboard": "",
               "from_time": "", "to_time": ""}
ON_ALERT_APIS = []


def required_json_convert(source, rs, measurement):
     """
     :param source: Error Source
     :param rs: influx json response
     :return: updated error hot list
     """
     if rs.raw.get('series'):
          for i in rs.raw['series']:
               if not i['values'][0][1]: # not
                    _ = dict_format.copy()
                    # _['api'] = i['tags']['api_name']
                    _['api'] = i['values'][0][2]
                    try:
                         _['group'] = i['values'][0][3]
                         second_query = "select * from {measurement} where \"group\" = "
                    except IndexError:
                         pass
                    _['from_time'] = i['values'][0][0]
                    _['source'] = source
                    ON_ALERT_APIS.append(_)


rs = client.query("select is_alert, api_name from nb_timeout_error group by api_name ORDER BY time DESC limit 1;", epoch='ns')
required_json_convert('OL NB', rs)

rs = client.query("select is_alert, api_name from sb_timeout_error group by api_name ORDER BY time DESC limit 1;", epoch='ns')
required_json_convert('OL SB', rs)

rs = client.query("select flag, api from kafka_measurement group by api  ORDER BY time DESC limit  1;", epoch='ns')
second_query = "select * from kafka_measurement where api = '{api}' and flag = 0 ORDER BY time DESC limit  1;"

required_json_convert('Kafka', rs)

rs = client.query('select flag, topic, "group" from kafka_lag_measurement group by "group", api  ORDER BY time DESC limit  1;', epoch='ns')
second_query = "select * from kafka_lag_measurement where \"group\" = '{group}' and topic = '{topic}' and flag = 0 ORDER BY time DESC limit  1;"

required_json_convert('Kafka Topic', rs)

pprint(ON_ALERT_APIS)


#########################################################################################


"""


fix also for metodo notification


nb 
sb done
select where alert = 0 and api = '', group = '' ORDER BY time DESC limit  1;
kafka 1    select flag from kafka_measurement group by api  ORDER BY time DESC limit  1;
kafka 2     select * from kafka_lag_measurement   ORDER BY time DESC limit  9;
               issue - group and topic --- 
               even group by won't work          
bss      no table


"""

"""
on chat bot

     available -         api, is_alert, details_dashboard, normal_dashboard
                                                  will give time range of last one day, or ......
     required - tree
               all at once
               
               or 
               
               no records found
               
               
     
"""

