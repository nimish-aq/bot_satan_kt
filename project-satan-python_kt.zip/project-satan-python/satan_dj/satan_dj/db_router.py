class DBRouter:
    """
    A router to control all database operations on models in the
    auth and contenttypes applications.
    """
    app_label = 'unknown_error'
    error_db = 'error_config'
    django_util_db = 'django_util'

    def db_router(self, model, **hints):
        if model._meta.app_label in self.app_label:
            return self.error_db
        return self.django_util_db

    def db_for_read(self, model, **hints):
        return self.db_router(model, **hints)

    def db_for_write(self, model, **hints):
        return self.db_router(model, **hints)

    # def allow_relation(self, obj1, obj2, **hints):
    #     return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        if app_label is not self.app_label:
            return db is not self.error_db
