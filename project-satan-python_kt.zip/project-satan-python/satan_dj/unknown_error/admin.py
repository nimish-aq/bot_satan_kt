from django.contrib import admin

from .error_db_models import *

# admin.site.register()



