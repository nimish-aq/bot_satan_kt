from django.apps import AppConfig


class UnknownErrorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'unknown_error'
