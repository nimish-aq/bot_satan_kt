# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.contrib import admin


class Api(models.Model):
    api_name = models.CharField(max_length=60)
    threshold_conditions = models.JSONField()
    api_name_slug = models.CharField(max_length=60, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'api'


class ApiError(models.Model):
    api = models.ForeignKey(Api, models.DO_NOTHING, db_column='api')
    error = models.ForeignKey('Error', models.CASCADE, db_column='error', related_name='error_apis')
    category = models.ForeignKey('ErrorCategory', models.DO_NOTHING, db_column='category')

    class Meta:
        managed = False
        db_table = 'api_error'
        unique_together = (('api', 'error', 'category'),)


class Error(models.Model):
    error = models.CharField(unique=True, max_length=500)
    error_code = models.IntegerField(unique=True, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'error'
        db_tablespace = 'error_config'


class ErrorCategory(models.Model):
    error_category = models.CharField(unique=True, max_length=45)

    class Meta:
        managed = False
        db_table = 'error_category'


class ErrorHistoryLog(models.Model):
    api_error = models.ForeignKey(ApiError, models.DO_NOTHING, db_column='api_error')
    epoch_time = models.CharField(max_length=19)
    date_time = models.DateTimeField()
    error_count = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'error_history_log'


class Process(models.Model):
    process = models.CharField(unique=True, max_length=100)

    class Meta:
        managed = False
        db_table = 'process'


class ProcessApiM2M(models.Model):
    process = models.ForeignKey(Process, models.DO_NOTHING, db_column='process')
    api = models.ForeignKey(Api, models.DO_NOTHING, db_column='api', related_name='api_m2m')

    class Meta:
        managed = False
        db_table = 'process_api_m2m'
        unique_together = (('api', 'process'),)
