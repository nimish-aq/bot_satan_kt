from django.urls import path
from . import views


urlpatterns = [
    # path('unknown-errors-map/', views.UnknownErrorMappingView.as_view(), name='unknown_errors_map'),
    path('unknown-errors-mapping/', views.UnknownErrorSubmitMultipleFormView.as_view(), name='unknown_errors_submit'),
]
