from django.views.generic import TemplateView
from django.db.models import F
from . import models

# category = 3 for unknown errors


def delete_error(error_text, error_id, api_id, category_id, api_error_id):
    models.Error.objects.filter(id=error_id).delete()


def update_unknown_error(error_text, error_id, api_id, category_id, api_error_id):
    # get or create error
    error_obj, _ = models.Error.objects.get_or_create(error=error_text)
    models.ApiError.objects.filter(api_id=api_id, error_id=error_id, category_id=3).delete()
    models.ApiError.objects.get_or_create(api_id=api_id, error_id=error_obj.id, category_id=category_id)
    return error_obj.id


class UnknownErrorSubmitMultipleFormView(TemplateView):
    """
    Renders a list of unknown errors, to be mapped manually by users
    """

    def post(self, request, *args, **kwargs):
        data = request.POST
        for i in range(1, int(request.POST.get('data_length'))+1):
            if data.get(f'category_pk{i}') == 'delete':
                delete_error(data[f'error_data_{i}'], data[f"error_pk{i}"], data[f"api_pk{i}"],
                                                data[f"category_pk{i}"], data[f"api_error_pk{i}"])
            elif data.get(f'category_pk{i}') != '3' and data.get(f'error_data_{i}').strip():
                error_id = update_unknown_error(data[f'error_data_{i}'], data[f"error_pk{i}"], data[f"api_pk{i}"],
                                                data[f"category_pk{i}"], data[f"api_error_pk{i}"])
        return self.get(request, *args, **kwargs)

    template_name = 'unknown_error_mapping.html'

    def get_context_data(self, **kwargs):
        context = {}
        context['unknown_errors'] = models.Error.objects.\
            filter(error_apis__category__error_category='unknown_errors').\
            annotate(api=F('error_apis__api__api_name')).\
            annotate(process=F('error_apis__api__api_m2m__process__process')).\
            annotate(error_pk=F('error_apis__error')).\
            annotate(api_error_pk=F('error_apis__id')).\
            annotate(api_pk=F('error_apis__api')).\
            order_by('api')

        context['data_length'] = len(context.get('unknown_errors', 0))
        context['categories'] = models.ErrorCategory.objects.exclude(error_category='unknown_errors')#.values_list('error_category', flat=True)
        # context['categories'] += ['delete']
        return context
