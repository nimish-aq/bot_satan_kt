SELECT  batch_job_type_api_name_mapping.api_name, batch_job_type_api_name_mapping.api_name as "JOB_ALIAS",
gc_notification_details.DETAIL, COUNT(gc_notification_details.DETAIL), gc_notification_details.DETAIL as "Detail Alias"
from gc_batch_job_details
left join gc_notification_details
on gc_batch_job_details.REQUEST_ID = gc_notification_details.REQUEST_ID
join batch_job_type_api_name_mapping
  on batch_job_type_api_name_mapping.job_type = gc_batch_job_details.JOB_TYPE
 where  gc_batch_job_details.CREATE_DATE BETWEEN FROM_UNIXTIME({lower_time}) AND FROM_UNIXTIME({current_time})
 and gc_batch_job_details.STATUS='failed'
  and batch_job_type_api_name_mapping.api_name = '{api}'
 group by gc_batch_job_details.JOB_TYPE;