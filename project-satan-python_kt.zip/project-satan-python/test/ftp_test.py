import pprint
#
# import MySQLdb
# creds = dict(host="192.168.1.231", user="root",
#              database="iotsmp_staging", password="Ttpl@123", port=3306)
# db_con = MySQLdb.connect(**creds)
# cursor = db_con.cursor()
# cursor.execute("select distinct API_NAME From auditlog_api_transaction;")
# data = cursor.fetchall()
#
# a = dict()
#
# for i in data:
#     if i[0]:
#         a[i[0]] = 8
# pprint.pprint(a)
p = """{'Attach Data Plan to Device\n': 8,
 'Change Device State': 8,
 'Change Password for Api User': 8,
 'ChangeSimGroups': 8,
 'ConsumedUsage': 8,
 'CreateSimsByOrderID': 8,
 'DeleteBan': 8,
 'Device Session History': 8,
 'Device Session Info': 8,
 'DeviceAttachDevicePlan': 8,
 'GcApi Auth': 8,
 'Get Account by Id': 8,
 'Get Attached Data Plan by Device ID': 8,
 'Get Data Usage': 8,
 'Get Device - Daimler': 8,
 'Get Device List': 8,
 'Get Device State - Hongdian': 8,
 'Get SIM': 8,
 'Get SIM State': 8,
 'Get device data usage New': 8,
 'Get eUICC Profile Status': 8,
 'GetAllSims': 8,
 'GetAllSimsByOrderID': 8,
 'GetDataPlans': 8,
 'GetDeviceByMsisdn': 8,
 'GetSmsUsagesByAccount': 8,
 'GetSmsUsagesSummary': 8,
 'GetVoiceUsagesByAccount': 8,
 'GetVoiceUsagesSummary': 8,
 'Ping': 8,
 'QueryExitingSubscrition': 8,
 'Replace Hardware-GM': 8,
 'SMSUsageSummary': 8,
 'Send SMS': 8,
 'Session wise data usage': 8,
 'Set eUICC Profile State': 8,
 'Sim Activation Trend': 8,
 'Sim Audit History': 8,
 'Sim Downlink usage': 8,
 'Sim List': 8,
 'Sim Rate Plan': 8,
 'Sim Uplink usage': 8,
 'Sim data session count': 8,
 'Switch Profile-GM': 8,
 'SwitchProfile': 8,
 'TagManagement': 8,
 'UnitConsumeSim': 8,
 'Update Device Settings': 8,
 'Update IMEI': 8,
 'Update Rating Profile': 8,
 'Update Sim Alias': 8,
 'Update Vehicle Identification Number': 8,
 'UsageSummary': 8,
 'VoiceUsageSummary': 8,
 'external api update device': 8}"""

p.replace("'", '"')
print(p)