"""select
           API_NAME as "API",
           API_NAME as "API Alias",
       SUM(CASE
             WHEN RESULT='success' THEN 1 --  or value  like '%200%'
             ELSE 0
           END) AS success_count,
 SUM(CASE
             WHEN  RESULT='Failed' THEN 1
             ELSE 0
           END) AS fail_count,

 count(*) as total
 from auditlog_api_transaction
 where  CREATE_DATE BETWEEN FROM_UNIXTIME(1638965018) AND FROM_UNIXTIME(1639569818)
 group by API_ID"""