from influx import InfluxDB

db = 'matrics'


"influx insert details  ['matrics', 'gc_process', 100.0, 0.0, 25.0, 1, 'attach data plan to device\n']"


error_percent, success_count, fail_count, is_alert, api = 100.0, 0.0, 25.0, 1.0, 'attach data plan to device\n'
print(api)
exit(0)

measurement = 'gc_process'

host_main = 'http://192.168.1.99:8086'

client = InfluxDB(host_main)
client.write_many(db, measurement,
                  fields=['error_percent', 'success_count', 'fail_count', 'is_alert'],
                  values=[[error_percent, success_count, fail_count, is_alert]],
                  tags={'api_name': api})
exit(0)

# client.create_database(db)

# client.write(db, measurement, fields={'flag': 0.0, 'lag_value': float(3)},
#              tags={'group': 'aman', 'topic': 'kaptaan'})


# client.query(f'delete from {measurement} where group= "aman" and topic = "kaptaan"')


# print(dir(client))
# print(dir(client))

alert_influx_data = client.select_where(db, measurement, fields='flag',
                                        tags={'group': 'aman', 'topic': 'kaptaan'},
                                        where='time > 0', desc=True, limit=1
                                        )

print(alert_influx_data)

rs = {'results': [{'statement_id': 0}]}

rs = {'results': [{'statement_id': 0, 'series': [{'name': 'bss_notification_test', 'columns': ['time', 'flag'], 'values': [[1635829489792926, 0]]}]}]}

