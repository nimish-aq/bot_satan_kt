a =""":Array[4,critical_errors]
:Array[1,global_errors]
:Array[2,http_errors]
:Array[6,ignore_errors]
:Array[7,no_errors]
:Array[3,unknown_errors]
:Array[5,warnings]"""

a = [
[4,"critical_errors"],
[1,"global_errors"],
[2,"http_errors"],
[6,"ignore_errors"],
[7,"no_errors"],
[3,"unknown_errors"],
[5,"warnings"]
]
for i in a:
    i = i[1]
    a = f"insert into error_category (error_category) values ('{i}');"
    print(a)
# print(a.replace(":Array", '').replace(']', '],'))

"insert into api (threshold_conditions, api_name) values select '{}', api_name from batch_job_type_api_name_mapping;"


"insert into process_api_m2m (process, api) select 2, id from api where id > 55;"